# GeoMapper Web Control

Simple webserver for controlling a standalone GeoMapper Docker Compose stack and downloading GeoMapper output files.

This version is intended to run on the GeoMapper computer itself.

## Functionality

- Web UI titled `GeoMapper Control`
- GeoMapper Start button
- GeoMapper Stop button
- Running/stopped/unknown status display
- File list from a configured path
- File modified date/time from filesystem metadata
- Browser download links for listed files

## How control works

The webserver uses Paramiko to SSH into the GeoMapper computer and run Docker Compose commands.

By default it connects to:

```text
127.0.0.1
```

This means the webserver container SSHs back into the host computer it is running on.

## Commands issued

By default, start runs:

```bash
docker compose -f <compose file> -p <project> up -d
```

Stop runs:

```bash
docker compose -f <compose file> -p <project> down
```

Status runs:

```bash
docker compose -f <compose file> -p <project> ps --status running --services
```

If the status command returns at least one running service, the UI shows `RUNNING`.

## Configuration

Most settings are in `docker-compose.yml`.

```yaml
GEOMAPPER_SSH_HOST: "127.0.0.1"
GEOMAPPER_SSH_USER: "geomapper"
GEOMAPPER_SSH_KEY_PATH: "/keys/id_ed25519"

GEOMAPPER_COMPOSE_WORKING_DIR: "/home/geomapper/geomapper-stack"
GEOMAPPER_COMPOSE_FILE: "/home/geomapper/geomapper-stack/docker-compose.yml"
GEOMAPPER_COMPOSE_PROJECT: "geomapper"

FILES_DIR: "/files"
FILES_GLOB: "*"
FILES_RECURSIVE: "false"
```

You can also fully override the commands:

```yaml
GEOMAPPER_START_COMMAND: "cd /home/geomapper/geomapper-stack && docker compose up -d"
GEOMAPPER_STOP_COMMAND: "cd /home/geomapper/geomapper-stack && docker compose down"
GEOMAPPER_STATUS_COMMAND: "cd /home/geomapper/geomapper-stack && docker compose ps --status running --services"
```

## SSH key setup

Place the private key in:

```text
keys/id_ed25519
```

The key is mounted read only into the container.

The public key must be in the GeoMapper user's `authorized_keys` file on the host.

Example:

```bash
ssh-copy-id -i keys/id_ed25519.pub geomapper@127.0.0.1
```

## Known hosts

By default the container rejects unknown SSH host keys.

Recommended setup:

```bash
ssh-keyscan -H 127.0.0.1 >> ~/.ssh/known_hosts
```

For early lab testing only, you can set:

```yaml
SSH_AUTO_ADD_HOST_KEY: "true"
```

## File downloads

The webserver lists files from the container path:

```text
/files
```

The default Compose file maps this from the host:

```yaml
volumes:
  - /home/geomapper/data:/files:ro
```

Change `/home/geomapper/data` to whatever directory contains your GeoMapper output files.

## Start

```bash
docker compose up --build
```

Open:

```text
http://<geomapper-computer-ip>:8080
```

## Security note

There is no authentication in this version. Use only on a trusted network or add authentication before broader deployment.

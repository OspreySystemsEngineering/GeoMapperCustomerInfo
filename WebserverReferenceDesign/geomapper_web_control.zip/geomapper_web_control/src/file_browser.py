import os
from datetime import datetime
from pathlib import Path


def list_available_files(files_dir: Path) -> list[dict]:
    if not files_dir.exists():
        return []

    recursive = os.environ.get("FILES_RECURSIVE", "false").lower() in ("1", "true", "yes", "on")
    pattern = os.environ.get("FILES_GLOB", "*")

    iterator = files_dir.rglob(pattern) if recursive else files_dir.glob(pattern)

    files = []
    for path in iterator:
        if not path.is_file():
            continue

        if path.name.startswith("."):
            continue

        stat = path.stat()
        relative_path = path.relative_to(files_dir)

        files.append(
            {
                "name": str(relative_path),
                "display_name": path.name,
                "size_bytes": stat.st_size,
                "modified": datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M:%S"),
            }
        )

    return sorted(files, key=lambda item: item["modified"], reverse=True)


def resolve_download_path(files_dir: Path, requested_filename: str) -> Path:
    base = files_dir.resolve()
    candidate = (base / requested_filename).resolve()

    if not str(candidate).startswith(str(base)):
        raise FileNotFoundError("Invalid download path")

    if not candidate.exists() or not candidate.is_file():
        raise FileNotFoundError("Requested file does not exist")

    return candidate

import os
import shlex
from dataclasses import dataclass

import paramiko


@dataclass
class CommandResult:
    exit_status: int
    stdout: str
    stderr: str


class GeoMapperService:
    def __init__(self) -> None:
        self.host = os.environ.get("GEOMAPPER_SSH_HOST", "127.0.0.1")
        self.user = os.environ.get("GEOMAPPER_SSH_USER", "")
        self.ssh_key_path = os.environ.get("GEOMAPPER_SSH_KEY_PATH", "/keys/id_ed25519")
        self.compose_file = os.environ.get("GEOMAPPER_COMPOSE_FILE", "")
        self.compose_project = os.environ.get("GEOMAPPER_COMPOSE_PROJECT", "geomapper")
        self.compose_working_dir = os.environ.get("GEOMAPPER_COMPOSE_WORKING_DIR", "")
        self.ssh_auto_add_host_key = _env_bool("SSH_AUTO_ADD_HOST_KEY", False)

        self.start_command = os.environ.get("GEOMAPPER_START_COMMAND") or self._build_compose_command("up -d")
        self.stop_command = os.environ.get("GEOMAPPER_STOP_COMMAND") or self._build_compose_command("down")
        self.status_command = os.environ.get("GEOMAPPER_STATUS_COMMAND") or self._build_compose_command("ps --status running --services")

    def start(self) -> CommandResult:
        return self._run_remote_command(self.start_command)

    def stop(self) -> CommandResult:
        return self._run_remote_command(self.stop_command)

    def get_status(self) -> dict:
        try:
            result = self._run_remote_command(self.status_command)
            running = result.exit_status == 0 and bool(result.stdout.strip())

            return {
                "running": running,
                "known": True,
                "stdout": result.stdout.strip(),
                "stderr": result.stderr.strip(),
                "exit_status": result.exit_status,
            }
        except Exception as exc:
            return {
                "running": False,
                "known": False,
                "stdout": "",
                "stderr": str(exc),
                "exit_status": None,
            }

    def _build_compose_command(self, suffix: str) -> str:
        parts = ["docker", "compose"]

        if self.compose_file:
            parts += ["-f", self.compose_file]

        if self.compose_project:
            parts += ["-p", self.compose_project]

        parts += suffix.split()

        command = " ".join(shlex.quote(part) for part in parts)

        if self.compose_working_dir:
            command = f"cd {shlex.quote(self.compose_working_dir)} && {command}"

        return command

    def _run_remote_command(self, command: str) -> CommandResult:
        if not self.user:
            raise RuntimeError("GEOMAPPER_SSH_USER must be set")

        ssh = paramiko.SSHClient()
        ssh.load_system_host_keys()

        if self.ssh_auto_add_host_key:
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        else:
            ssh.set_missing_host_key_policy(paramiko.RejectPolicy())

        key = _load_private_key(self.ssh_key_path)

        try:
            ssh.connect(
                hostname=self.host,
                username=self.user,
                pkey=key,
                timeout=int(os.environ.get("SSH_CONNECT_TIMEOUT_S", "20")),
                banner_timeout=int(os.environ.get("SSH_BANNER_TIMEOUT_S", "20")),
                auth_timeout=int(os.environ.get("SSH_AUTH_TIMEOUT_S", "20")),
            )

            stdin, stdout, stderr = ssh.exec_command(command)
            exit_status = stdout.channel.recv_exit_status()

            return CommandResult(
                exit_status=exit_status,
                stdout=stdout.read().decode(errors="replace"),
                stderr=stderr.read().decode(errors="replace"),
            )
        finally:
            ssh.close()


def _load_private_key(key_path: str):
    passphrase = os.environ.get("SSH_KEY_PASSPHRASE") or None

    key_loaders = [
        paramiko.Ed25519Key,
        paramiko.RSAKey,
        paramiko.ECDSAKey,
    ]

    last_error = None
    for loader in key_loaders:
        try:
            return loader.from_private_key_file(key_path, password=passphrase)
        except Exception as exc:
            last_error = exc

    raise RuntimeError(f"Failed to load SSH private key at {key_path}: {last_error}")


def _env_bool(name: str, default: bool) -> bool:
    value = os.environ.get(name)

    if value is None:
        return default

    return value.strip().lower() in ("1", "true", "yes", "on")


geomapper_service = GeoMapperService()

import os
from pathlib import Path

from flask import Flask, render_template, request, redirect, url_for, send_from_directory, flash

from geomapper_control import geomapper_service
from file_browser import list_available_files, resolve_download_path


APP_PORT = int(os.environ.get("APP_PORT", "8080"))
FILES_DIR = Path(os.environ.get("FILES_DIR", "/files"))

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY", "geomapper-web-control-dev-key-change-me")


@app.route("/", methods=["GET"])
def index():
    service_status = geomapper_service.get_status()
    available_files = list_available_files(FILES_DIR)

    return render_template(
        "index.html",
        service_status=service_status,
        files=available_files,
    )


@app.route("/geomapper/start", methods=["POST"])
def start_geomapper():
    try:
        geomapper_service.start()
        flash("GeoMapper start command issued", "success")
    except Exception as exc:
        flash(f"Failed to start GeoMapper: {exc}", "error")

    return redirect(url_for("index"))


@app.route("/geomapper/stop", methods=["POST"])
def stop_geomapper():
    try:
        geomapper_service.stop()
        flash("GeoMapper stop command issued", "success")
    except Exception as exc:
        flash(f"Failed to stop GeoMapper: {exc}", "error")

    return redirect(url_for("index"))


@app.route("/download/<path:filename>", methods=["GET"])
def download(filename):
    file_path = resolve_download_path(FILES_DIR, filename)

    return send_from_directory(
        file_path.parent,
        file_path.name,
        as_attachment=True,
    )


@app.route("/health", methods=["GET"])
def health():
    return {
        "status": "ok",
        "geomapper": geomapper_service.get_status(),
    }


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=APP_PORT)
